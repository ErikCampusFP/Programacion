package dao.repository;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import dao.database.ConexionBD;
import dao.model.Producto;

public class RepositorioProductoDAO implements RepositorioDAO<Producto, Integer> {

    @Override
    public boolean add(Producto data) {
        String sql = "INSERT INTO PRODUCTO (idProducto, medida, nombre, precio, stock) VALUES (?, ?, ?, ?, ?)";

        try (PreparedStatement ps = ConexionBD.getConexion().prepareStatement(sql)) {
            ps.setInt(1, data.getIdproducto());
            ps.setString(2, data.getMedida());
            ps.setString(3, data.getNombre());
            ps.setInt(4, data.getPrecio());
            ps.setInt(5, data.getStock());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return false;
        }
    }

    @Override
    public boolean remove(Integer id) {
        String sql = "DELETE FROM PRODUCTO WHERE idProducto = ?";

        try (PreparedStatement ps = ConexionBD.getConexion().prepareStatement(sql)) {
            ps.setInt(1, id);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return false;
        }
    }

    @Override
    public Producto findById(Integer id) {
        String sql = "SELECT * FROM PRODUCTO WHERE idProducto = ?";

        try (PreparedStatement ps = ConexionBD.getConexion().prepareStatement(sql)) {
            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Producto p = new Producto();
                    p.setIdproducto(rs.getInt("idProducto"));
                    p.setMedida(rs.getString("medida"));
                    p.setNombre(rs.getString("nombre"));
                    p.setPrecio(rs.getInt("precio"));
                    p.setStock(rs.getInt("stock"));
                    return p;
                }
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return null;
    }

    @Override
    public boolean update(Producto data) {
        String sql = "UPDATE PRODUCTO SET medida = ?, nombre = ?, precio = ?, stock = ? WHERE idProducto = ?";

        try (PreparedStatement ps = ConexionBD.getConexion().prepareStatement(sql)) {
            ps.setString(1, data.getMedida());
            ps.setString(2, data.getNombre());
            ps.setInt(3, data.getPrecio());
            ps.setInt(4, data.getStock());
            ps.setInt(5, data.getIdproducto());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println(e.getMessage());
            return false;
        }
    }

    @Override
    public List<Producto> getList() {
        String sql = "SELECT * FROM PRODUCTO";
        List<Producto> productos = new ArrayList<>();

        try (
            Statement statement = ConexionBD.getConexion().createStatement();
            ResultSet rs = statement.executeQuery(sql)
        ) {
            while (rs.next()) {
                Producto p = new Producto();
                p.setIdproducto(rs.getInt("idProducto"));
                p.setMedida(rs.getString("medida"));
                p.setNombre(rs.getString("nombre"));
                p.setPrecio(rs.getInt("precio"));
                p.setStock(rs.getInt("stock"));

                productos.add(p);
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return productos;
    }

    public List<Producto> getProductosPorCategoria(Integer idCategoria) {
        String sql = "SELECT * FROM PRODUCTO WHERE idCategoria = ?";
        List<Producto> productos = new ArrayList<>();

        try (PreparedStatement ps = ConexionBD.getConexion().prepareStatement(sql)) {
            ps.setInt(1, idCategoria);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Producto p = new Producto();
                    p.setIdproducto(rs.getInt("idProducto"));
                    p.setMedida(rs.getString("medida"));
                    p.setNombre(rs.getString("nombre"));
                    p.setPrecio(rs.getInt("precio"));
                    p.setStock(rs.getInt("stock"));

                    productos.add(p);
                }
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return productos;
    }
}