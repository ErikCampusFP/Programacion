import java.util.Scanner;
public class EjercicioCadenas {

	public static void main(String[] args) {
		
		Scanner lector = new Scanner (System.in);

		// Ejercicio 1 - Longitud de la cadena
		System.out.println("Ejercicio 1 - Longitud de la cadena");
		System.out.println("  ");
			
		String frase = "Buenas Noches A Todos";
		
		int longitudFrase = frase.length();
		System.out.println(frase);
		System.out.println("La longitud de la frase es de: " + longitudFrase);
		
		System.out.println("------------------------------------------------");
		System.out.println("  ");

		// Ejercicio 2 - Acceso a caracteres
		System.out.println("Ejercicio 2 - Acceso a caracteres");
		System.out.println("  ");
		
		System.out.println("Primer caracter: " + frase.charAt(0)); // Primer caracter
		
		longitudFrase = frase.length() - 1;
		System.out.println("Ultimo caracter: " + frase.charAt(longitudFrase)); // Ultimo caracter
		
		System.out.println("5 caracter: " + frase.charAt(4)); // 5 caracter
		
		System.out.println("------------------------------------------------");
		System.out.println("  ");

		// Ejercicio 3 - Búsqueda de texto
		System.out.println("Ejercicio 3 - Búsqueda de texto");
		System.out.println("  ");
		
		boolean contiene = frase.contains("Noches");
		
		if(contiene == false) {
			System.out.println("La frase no posee la palabra concreta");
		} else {
			System.out.println("Su primera aparición es la siguiente: " + frase.indexOf("Noches"));
			System.out.println("Su ultima aparición es la siguiente: " + frase.lastIndexOf("Noches"));

		}
		System.out.println("------------------------------------------------");
		System.out.println("  ");

		
		// Ejercicio 4 - Comparación de cadenas
		System.out.println("Ejercicio 4 - Comparación de cadenas");
		System.out.println("  ");
		
		String frase1 = "Hola";
		String frase2 = "hola";
		
		System.out.println("Son exactamente iguales: " + frase1.equals(frase2));
		System.out.println("Son iguales ignorando máyusculas y minúsculas: " + frase1.equalsIgnoreCase(frase2));
		
		int resultado = frase1.compareTo(frase2);

		if (resultado < 0) {
		    System.out.println(frase1 + " va antes que " + frase2);
		} else if (resultado > 0) {
		    System.out.println(frase1 + " va después que " + frase2);
		} else {
		    System.out.println("Ambas cadenas son iguales");
		}
		
		System.out.println("------------------------------------------------");
		System.out.println("  ");
		
		
		
		// Ejercicio 5 – Extracción de partes de una cadena
		System.out.println("Ejercicio 5 – Extracción de partes de una cadena");
		System.out.println("  ");
		
		System.out.println("Los primeros 5 digitos son los siguientes: " + frase.substring(0,5));
		System.out.println("Los digitos desde el 3 hasta el 8 son los siguientes: " + frase.substring(3,8)); 
		System.out.println("Los digitos desde el 5 hasta el final son los siguientes: " + frase.substring(5,longitudFrase)); 

		System.out.println("------------------------------------------------");
		System.out.println("  ");
		
		
		// Ejercicio 6 - Conversión de texto
		System.out.println("Ejercicio 6 - Conversión de texto");
		System.out.println("  ");
		
		System.out.println("El texto en mayusculas: " + frase.toUpperCase());
		System.out.println("El texto en minusculas: " + frase.toLowerCase());
		System.out.println("El texto sin espacios al principio ni al final: " + frase.trim());
		
		System.out.println("------------------------------------------------");
		System.out.println("  ");
		
		
		// Ejercicio 7 – Reemplazo de texto
		System.out.println("Ejercicio 7 – Reemplazo de texto");
		System.out.println("  ");
		
		System.out.println("Sustuimos Buenas por Hola: " + frase.replace("Buenas", "Hola"));
		System.out.println("Sustituir todas las 'o' por '0': " + frase.replaceAll("o", "0"));
		System.out.println("Sustituir primera aparición de 'o' por '0': " + frase.replaceFirst("o", "0"));

		System.out.println("------------------------------------------------");
		System.out.println("  ");
		
		
		// Ejercicio 8 – Separación de una cadena
		System.out.println("Ejercicio 8 – Separación de una cadena");
		System.out.println("  ");
		
		String[] stringFrase = frase.split(" "); // Frase dividida en un array y separada por espacios
		System.out.println("Palabras de la frase: ");
		
		for(String palabra : stringFrase) {
			System.out.println(palabra);
		}
		
		System.out.println("Cuantas palabras contiene la cadena: " + stringFrase.length);
		
		System.out.println("------------------------------------------------");
		System.out.println("  ");
		
		// Ejercicio 9 – Conteo de caracteres
		System.out.println("Ejercicio 9 – Conteo de caracteres");
		System.out.println("  ");
		
		int vocales = 0;
		int espacios = 0;
		
		for(int contador = 0; contador != frase.length(); contador+=1) {
			
			if(contador > frase.length()) {
				break;
			}
			
			char caracter = frase.charAt(contador);
			
			if (caracter == 'a' || caracter == 'e' || caracter == 'i' || caracter == 'o' || caracter == 'u') {
				vocales +=1;
			}
			
			if (caracter == 'A' || caracter == 'E' || caracter == 'I' || caracter == 'O' || caracter == 'U') {
				vocales +=1;
			}
			
			if (caracter == ' ') {
				espacios +=1;
			}
		}
		
		System.out.println("Numero de vocales: " + vocales);
		System.out.println("Numero de espacios: " + espacios);
		
		System.out.println("------------------------------------------------");
		System.out.println("  ");
		
		
		// Ejercicio 10 – Análisis de una cadena
		System.out.println("Ejercicio 10 – Análisis de una cadena");
		System.out.println("  ");
		
		System.out.println("Escribe una frase: ");
		
		String fraseUsuario = lector.next();
		
		System.out.println("La frase es la siguiente: " + fraseUsuario);
		System.out.println("Numero de caracteres: " + fraseUsuario.length());
		System.out.println("Primer caracter: " + fraseUsuario.charAt(0));
		System.out.println("Último carácter: " + fraseUsuario.charAt(fraseUsuario.length() - 1));
		
		boolean contieneNumeros = false;
		String contieneNumeros1 = "";
		for (int i = 0; i < fraseUsuario.length(); i++) {
		    if (Character.isDigit(fraseUsuario.charAt(i))) {
		        contieneNumeros = true;
		        break;
		    }
		}
		
		if(contieneNumeros == true) {
			contieneNumeros1 = "Si";
		} else {
			contieneNumeros1 = "No";
		}
		
		System.out.println("¿Contiene números?: " + contieneNumeros1);
		
		String cadenaInvertida = new StringBuilder(fraseUsuario).reverse().toString();
		System.out.println("Texto Invertido: " + cadenaInvertida);
		
		
		lector.nextLine(); // Limpia el buffer del scanner
		
		System.out.println("Introduce el carácter con el que quieres comprobar si acaba: ");
		String caracterFinal = lector.nextLine();

		if (fraseUsuario.endsWith(caracterFinal)) {
		    System.out.println("La frase SÍ termina con " + caracterFinal);
		} else {
		    System.out.println("La frase NO termina con "  + caracterFinal);
		}	
		
		
		lector.close();
	}

}
