
public class Bebida {
	private int precio;
	private String nombre;
	private int stock;
	
	
	public Bebida(int precio, String nombre, int stock) {
		super();
		this.precio = precio;
		this.nombre = nombre;
		this.stock = stock;
	}


	public Bebida(Bebida b) {
	    this.precio = b.precio;
	    this.nombre = b.nombre;
		this.stock = b.stock;

	}

	public int getPrecio() {
		return precio;
	}


	public void setPrecio(int precio) {
		this.precio = precio;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	

	public int getStock() {
		return stock;
	}


	public void setStock(int stock) {
		this.stock = stock;
	}
	
	public void bajarStock() {
		this.stock -= 1;
	}


	@Override
	public String toString() {
		return "Bebida [precio=" + precio + ", nombre=" + nombre + "]";
	}


	
	
	
	
}
